package Text;
import java.util.Scanner;

class aaa {
	private String name;
	private int speed;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSpeed() {
		return speed;
	}

	public void setSpeed(int speed) {
		this.speed = speed;
	}

	public void show() {
		System.out.println("    车主:" + this.name);
		System.out.println("    车速:" + this.speed);
	}

	public void changeNameSpeed() {
		// TODO 自动生成的方法存根
		Scanner b = new Scanner(System.in);
		Scanner c = new Scanner(System.in);
		System.out.println("修改车主:");
		this.name = b.next();
		System.out.println("修改车速:");
		this.speed = c.nextInt();
		// System.out.println("修改车主："+this.name);System.out.println("修改车速："+this.speed);
		b.close();
		c.close();
	}

	public void stop() {
		this.speed = 0;
		System.out.println("停车后车速:" + this.speed);
	}
}
public class car {
	public static void main(String[] args) {
		// TODO 自动生成的方法存根
		aaa a = new aaa();
		a.setName("zhupenghui");
		a.setSpeed(0);
		a.show();
		a.changeNameSpeed();
		a.show();
		System.out.println("-------------");
		a.stop();

	}
}