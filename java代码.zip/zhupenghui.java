package Text;
import java.util.Scanner;//接口

class MyProgram {
	private int data;//声明一个名data的数
	private String str;//声明一个str的字符串

	public void setData(int data) {
		this.data = data;
	}//实现data和str的对应

	public void setStr(String str) {
		this.str = str;
	}

	int getData() {
		return data;
	}//调用data

	String getStr() {
		return str;
	}//调用str

	public String toString() {
		return "zhupenghui [data=" + data + ", str=" + str + "]";
	}//返回zhupenghui[data=,str=]

}

public class zhupenghui {
	public static void main(String[] args) {

		MyProgram M = new MyProgram();
		Scanner a = new Scanner(System.in);//接受键盘输入的数据
		M.setData(a.nextInt());
		M.setStr(a.next());
		a.close();
		System.out.println(M);
	}

}
