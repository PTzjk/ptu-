package Text;
import java.util.Scanner;

class bbb {
	String xuehao;//学号
	String banji;//班级
	String name;//姓名
	String gender;//性别
	String age;//年龄

	public String getXuehao() {
		return xuehao;
	}

	public void setXuehao(String xuehao) {
		
		this.xuehao = xuehao;
	}

	public String getBanji() {
		return banji;
	}

	public void setBanji(String banji) {
		this.banji = banji;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public void printInfo() {
		System.out.println("学号："+this.xuehao);
		System.out.println("班级："+this.banji);
		System.out.println("姓名："+this.name);
		System.out.println("性别："+this.gender);
		System.out.println("年龄："+this.age);
	}
}

public class student {
	public static void main(String[] args) {
		// TODO 自动生成的方法存根
		bbb S = new bbb();
		Scanner a=new Scanner(System.in);
		System.out.println("输入学号:");
		S.setXuehao(a.next());
		System.out.println("输入班级:");
		S.setBanji(a.next());	
		System.out.println("输入姓名:");
		S.setName(a.next());	
		System.out.println("输入性别:");
		S.setGender(a.next());
		System.out.println("输入年龄:");
		S.setAge(a.next());
		S.printInfo();
		a.close();
	}
}