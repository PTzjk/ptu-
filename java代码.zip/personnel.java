package Text;
import java.util.Scanner;

class Person {
	String name;
	String address;

	public Person() {
		// TODO 自动生成的构造函数存根

	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddre(String address) {
		this.address = address;
	}

}

class Employee extends Person {
	String ID;
	double wage;
	int workAge;

	public String getID() {
		return ID;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public double getWage() {
		return wage;
	}

	public void setWage(double wage) {
		this.wage = wage;
	}

	public int getWorkAge() {
		return workAge;
	}

	public void setWorkAge(int workAge) {
		this.workAge = workAge;
	}

	public Employee() {
		// TODO 自动生成的构造函数存根
	}

	public void addVage() {
		wage += wage * 0.1;
	}

	public void show() {
		System.out.println("name:" + getName() + " " + "address:" + getAddress() + " " + "id:" + getID() + " " + "wage:"
				+ getWage() + " " + "workage:" + getWorkAge());
	}
}

class Manager extends Employee {
	String level;

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public Manager() {
		// TODO 自动生成的构造函数存根
	}

	public void addVage() {
		wage += wage * 0.2;
	}

	public void show() {
		System.out.println("name:" + getName() + " " + "address:" + getAddress() + " " + "id:" + getID() + " " + "wage:"
				+ getWage() + " " + "workage:" + getWorkAge() + " " + "level:" + getLevel());
	}
}

interface Add {
	abstract void addVage();
}
public class personnel {
	public static void main(String[] args) {
		// TODO 自动生成的方法存根
		System.out.println("初始信息");
		Manager m = new Manager();
		Scanner b = new Scanner(System.in);
		System.out.println("名字");
		m.setName(b.next());
		System.out.println("地址");m.setAddre(b.next());
		System.out.println("ID");m.setID(b.next());
		System.out.println("工资");m.setWage(b.nextDouble());
		System.out.println("工龄");m.setWorkAge(b.nextInt());
		System.out.println("级别");m.setLevel(b.next());
		Employee e = new Employee();
		System.out.println("名字");e.setName(b.next());
		System.out.println("地址");e.setAddre(b.next());
		System.out.println("ID");e.setID(b.next());
		System.out.println("工资");e.setWage(b.nextDouble());
		System.out.println("工龄");e.setWorkAge(b.nextInt());
		m.show();e.show();
		m.addVage();
		e.addVage();
		System.out.println("涨工资后");
		m.show();
		e.show();
		b.close();
	}

}